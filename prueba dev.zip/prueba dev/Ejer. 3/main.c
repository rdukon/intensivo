#include <stdio.h>
#include <stdlib.h>

int main()
{
  
  float pres1,pres2,presp,r,cont,contm,porcent,varmayor=0,numlect;
  
  printf("Buenos dias,desea realizar un control? \n1:Si \n2:No");
  scanf("%f",&r);
  
  while(r==1){
    
    cont++;
                
    printf("\nIngrese presion 1:");            
    scanf("%f",&pres1);            
                
    printf("\nIngrese presion 2:");
    scanf("%f",&pres2);            
    
    presp=(pres1+pres2)/2;
    
    if(presp<180){
                  
    printf("\nLa presion del caldero es baja,con una presion de :%f",presp);              
                  
    }
    
    if(presp<350 && presp>=180){
    
    printf("\nLa presion del caldero es moderada,con una presion de :%f",presp);
    contm++;
    
    }
     
    if(presp>=350 && presp<590){
    
    printf("\nLa presion del caldero es aceptable,con una presion de :%f",presp);
                 
    }
    if(presp>=590){
    
    printf("\nLa presion del caldero esta en riesgo,con una presion de :%f",presp);      
          
    }
    
    if(varmayor<=presp && presp>=590){                 
    varmayor=presp;
    numlect=cont;                  
    }
    printf("\nDesea realizar otro control? \n1:Si \n2:No");
    scanf("%f",&r);           
  }
  
  if(varmayor==0){
  printf("Nunca hubo una situacion de riesgo");
  }else{     
  printf("Se presento situaciones de riesgo,cuya mayor presion promedio fue de:%f \nLa cual se presento en la lectura:%f",varmayor,numlect);
  }
  
  porcent=(contm/cont)*100;
  
  printf("\nEl porcentaje de veces con un control moderado fue de %f",porcent);
  
  system("PAUSE");	
  return 0;
}

