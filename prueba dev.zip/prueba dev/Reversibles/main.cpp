#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <string.h>
using namespace std;

int main()
{
  int num,rev=0,aux,ult,sum,pares=0,aux2;
  
  printf("Ingrese un numero que desee comprobar como reversible:");
  scanf("%d",&num);
  
  aux=num;
  
  while(aux>0){
                
   ult=aux%10;
   
   rev=rev*10+ult;            
                
   aux=(aux-ult)/10;             
                                          
  }
  
  sum=num+rev;
  
  aux2=sum;
  
  while(pares==0 && aux2>0){
  
                  
  ult=aux2%10;                
                  
  if(ult%2==0){             
  pares=pares+1;             
  }                
  
  aux2=(aux2-ult)/10;
  }
  
  if(pares!=0){
               
  printf("No es un numero reversible,%d",sum);             
               
  }else{
        
  printf("Es un numero reversible,%d",sum);
        
  }      
system("PAUSE");
return EXIT_SUCCESS;
}
