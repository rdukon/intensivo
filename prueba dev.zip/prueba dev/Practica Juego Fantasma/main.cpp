#include <cstdlib>
#include <iostream>
#include <time.h>
#include <conio.h>
#include <windows.h>
#include <math.h>

#define ARRIBA 72
#define ABAJO 80
#define IZQUIERDA 75
#define DERECHA 77

using namespace std;

void imprimir(int mapa[20][20]);

void mover(int mapa[20][20]);

int main(int argc, char *argv[]){
    
    int mapa[20][20]={  
                     {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},                  
                     {1,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,2,1},                   
                     {1,0,1,0,1,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1},                   
                     {1,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},                   
                     {1,0,1,0,1,1,1,0,1,0,1,1,0,0,1,1,1,1,0,1},                   
                     {1,0,0,0,0,0,0,0,1,0,1,1,1,1,1,0,1,1,0,1},                   
                     {1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,1},                   
                     {1,0,0,0,0,0,0,0,1,0,1,0,1,1,1,0,1,0,1,1},                   
                     {1,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,1,0,1,1},                   
                     {1,0,1,0,1,0,0,0,0,0,1,0,1,1,1,1,1,0,0,1},                   
                     {1,0,1,0,1,0,1,0,1,1,1,0,0,0,0,0,1,1,0,1},                   
                     {1,0,1,0,0,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1},                   
                     {1,0,1,0,0,1,1,0,1,0,0,0,1,0,1,0,1,1,0,1},  
                     {1,0,1,0,0,1,0,0,1,0,1,0,1,0,0,0,0,1,0,1},                   
                     {1,0,1,1,1,1,0,1,1,0,1,0,1,0,1,1,1,1,0,1},                   
                     {1,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1},                   
                     {1,0,1,1,1,1,1,0,1,0,1,0,0,0,1,0,1,1,0,1},                   
                     {1,0,1,0,0,0,0,0,1,1,1,0,1,1,1,0,0,0,0,1},                   
                     {1,0,1,0,1,1,0,0,0,0,1,0,0,0,1,0,0,1,0,1},                                                                  
                     {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
    
    mapa[1][1]=3;
    mapa[18][18]=4;
    
    imprimir(mapa);
    
    mover(mapa);

    return EXIT_SUCCESS;
}
void imprimir(int mapa[20][20]){
     
     int a,b;
     
     system("cls");
     
     for(a=0;a<20;a++){
     printf("\t\t");
         for(b=0;b<20;b++){
             if(mapa[a][b]==1){
             printf("%c",219);          
             }else if(mapa[a][b]==0){
             printf(" ");            
             }else if(mapa[a][b]==3){
             printf("@");
             }else if(mapa[a][b]==2){
             printf("X");      
             }else{
             printf("*");      
             }                                  
         }  
         printf("\n");               
     }     
     printf("\n\n\t\tPara salir,presione s");
}

void mover(int mapa[20][20]){
     
     int mov;     
     int x1=1,y1=1;
     int x2=18,y2=18;
     int difx,dify;
     int control,control2,cont=0;
     int aux=0;
     
     control=0;
     
     control2=0;
     
     do{
     if(kbhit()){
     mov=getch();
     control=1;
     }
     switch(mov)
     {          
                case ARRIBA:
                     if(mapa[x1-1][y1]==0 || mapa[x1-1][y1]==2){
                     mapa[x1-1][y1]=3;
                     mapa[x1][y1]=0; 
                     x1--;                                          
                     }
                           break;
                
                case ABAJO:
                     if(mapa[x1+1][y1]==0 || mapa[x1+1][y1]==2){
                     mapa[x1+1][y1]=3;
                     mapa[x1][y1]=0; 
                     x1++;                                          
                     }
                           break;
                           
                case IZQUIERDA:
                     if(mapa[x1][y1-1]==0 || mapa[x1][y1-1]==2){
                     mapa[x1][y1-1]=3;
                     mapa[x1][y1]=0; 
                     y1--;                                          
                     }
                           break;
                           
                case DERECHA:
                     if(mapa[x1][y1+1]==0 || mapa[x1][y1+1]==2){
                     mapa[x1][y1+1]=3;
                     mapa[x1][y1]=0; 
                     y1++;                                          
                     }
                           break;
      }
      difx=x1-x2;
      dify=y1-y2;
      
      mapa[x2][y2]=aux;
      
      cont++;
      
      if(control==1 && cont%5==0){
      if(abs(difx)>abs(dify)){
           if(difx>0){
           x2++;           
           }else if(difx<0){
           x2--;      
           }                        
      }else{
          if(dify>0){
           y2++;           
           }else if(dify<0){
           y2--;
           }  
      }
      }
      
      aux=mapa[x2][y2];
      mapa[x2][y2]=4;
      
      if(x1==1 && y1==18){
      control2=1;         
      }
      
      Sleep(100);
      imprimir(mapa);
      }while(mov!='s' && !(x1==x2 && y1==y2) && control2==0);
      if(mov!='s' && control2==0)
      {
            printf("\n\nPERDIOOO!!!!!\n");
            printf("\n");
            system("pause");      
      }else if(control2==1){
            printf("\n\nGANASTEEE!!!!!!"); 
            printf("\n\n");
            system("pause");     
      }else{
            printf("\n\nTe retiraste,cagon"); 
            printf("\n");
            system("pause");     
      }
}
