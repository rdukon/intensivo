#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <string.h>

int main()
{
  float num,rev,aux,ult;
  
  printf("Ingrese un numero que desee comprobar como reversible:");
  scanf("%f",&num);
  
  aux=num;
  
  while(aux>10){
                
   ult=aux%10;
   
   rev=rev*10+ult;            
                
   aux=(aux-ult)/10;             
                                          
  }
  
  printf("%f",rev);
  
  
  
  
  
  
  
  
  
  system("PAUSE");	
  return 0;
}
