#include <cstdlib>
#include <iostream>
#include <string.h>
#include <math.h>

using namespace std;

int main(){
    
    char nomequipo[60],nomganador[60];
    float medidas,longc,prom,error,totalp,res,cont1,eganador=999999999,porce,cont2=0,med1,cont3=0;
    
    do{
    printf("\n\nIngrese el nombre del equipo:");
    fflush(stdin);
    gets(nomequipo);
    fflush(stdin);
    
    totalp=0;
    cont1=0;
    do{
    cont1++;
    cont3++;
    printf("\n\nIngrese una medida:");
    scanf("%f",&medidas);
    
    totalp=totalp+medidas;
    
    printf("\n\nDesea ingresar otra medida?\n1:Si \n2:No\n:");
    scanf("%f",&res);
    }while(res==1);
    
    printf("Ingrese la longitud correcta:");
    scanf("%f",&longc);
    
    prom=totalp/cont1;
    error=longc-prom;
    
    printf("\n\nLa longitud promedio fue de:%f",prom);
    printf("\n\nEl error cometido fue de:%f",error);
    
    porce=(fabs(error)/longc)*100;
    
    if(fabs(error)<eganador){
    strcpy(nomganador,nomequipo);                   
    eganador=fabs(error);
    }
    
    if(porce>=17){
    cont2++;              
    }
    
    printf("\n\nDesea ingresar otro equipo? \n1:Si \n2:No\n:");
    scanf("%f",&res);
    }while(res==1);
    
    printf("\n\nEl equipo ganador fue %s,con un error de:%f",nomganador,eganador);
    
    printf("\n\nEl total de equipos con mas de 17 por ciento de error fue de:%f\n",cont2);
    
    printf("\n\nIngrese el total de mediciones que hubo el concurso pasado:");
    scanf("%f",&med1);
    
    if(cont3>med1){
    printf("\n\nEl total de medidas aumento respecto al concurso pasado");               
    }else{
    printf("\n\nEl total de medidas no ha aumentado respecto al concurso pasado\n\n");      
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
