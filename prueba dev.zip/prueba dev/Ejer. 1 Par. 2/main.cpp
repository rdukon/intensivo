#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int vec_a[30],vec_b[30],vec_c[30],x,m1[15][15],m2[15][15],y,vec_d[60],vec_aux[30],menor,pos,aux;
    int vec_e[30],vec_f[30],contf=0,vec_g[30],m3[15][15];
    float contp=0,porcp,porci;
    srand(time(NULL));
    
    for(x=0;x<30;x++){
    vec_a[x]=rand()%900+100;
    vec_b[x]=(rand()%450+50)*2;
    vec_c[x]=(rand()%450+50)*2+1;                  
    }
    
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    m1[x][y]=rand()%900+100; 
    m2[x][y]=rand()%9000+1000;
    if(m2[x][y]%2==0){
    contp++;             
    }                  
    }                  
    }
//==============================================================================    
    printf("Vector a,b,c\n\n");   
    for(x=0;x<30;x++){
    printf("%d        %d      %d\n",vec_a[x],vec_b[x],vec_c[x]); 
    }
    system("pause");
    system("cls");
    //Muestra de matriz
    printf("Matriz 1\n\n");
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    printf("%d ",m1[x][y]);                  
    }
    printf("\n");                  
    }
    
    system("pause");
    system("cls");
    
    printf("Matriz 2\n\n");
    
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    printf("%d ",m2[x][y]);                  
    }
    printf("\n");                  
    }    
    
    system("pause");
    system("cls");
    
    printf("Vector a derecho y revez\n\n");
    
    for(x=0;x<30;x++){
    printf("%d        %d\n",vec_a[x],vec_a[29-x]);                  
    }
    
    system("pause");
    system("cls");
    
    printf("Vector d\n\n");
    
    for(x=0;x<30;x++){
    vec_d[x*2]=vec_b[x];
    vec_d[x*2+1]=vec_c[x];                    
    }
    
    for(x=0;x<6;x++){
    
    for(y=0;y<5;y++)
    {
         printf("\n%d            %d\n",vec_b[x*5+y],vec_c[x*5+y]);           
    }
    printf("\n");
    for(y=0;y<10;y++){
    printf("%d  ",vec_d[x*10+y]);                  
    }               
    printf("\n");  
    system("pause");
    system("cls");                 
    }
    
    printf("Vector a,normal y de menor a mayor\n");
    
    for(x=0;x<30;x++){
    vec_aux[x]=vec_a[x];                  
    }
    
    for(x=0;x<30;x++){
    menor=1000;
    pos=-1;
           for(y=x;y<30;y++){
                             if(vec_aux[y]<menor){
                             menor=vec_aux[y];
                             pos=y;
                             }                                    
           }
    aux=vec_aux[x];
    vec_aux[x]=vec_aux[pos];
    vec_aux[pos]=aux;
    }
    
    for(x=0;x<30;x++){
    printf("%d        %d\n",vec_a[x],vec_aux[x]);                  
    }
    
    system("pause");
    system("cls");
    
    printf("Vector e\n\n");
    
    for(x=0;x<15;x++){
    vec_e[x]=vec_b[x+15];
    vec_e[x+15]=vec_c[x];                  
    }
    
    for(x=0;x<30;x++){
    printf("%d        %d         %d\n",vec_b[x],vec_c[x],vec_e[x]);                  
    }
    system("pause");
    system("cls");
    
    printf("Vector f\n\n");
    
    for(x=0;x<30;x++){
                      if(vec_a[x]%2==0){
                      vec_f[contf]=vec_a[x];
                      contf++;                  
                      }                  
    }
    
    for(x=0;x<contf;x++){
    printf("%d\n",vec_f[x]);                  
    }
    
    system("pause");
    system("cls");
    
    printf("Vector g\n\n");
    
    for(x=0;x<30;x++){
    vec_g[x]=vec_b[x]*1000+vec_c[x];                  
    }
    
    for(x=0;x<30;x++){
    printf("%d        %d          %d\n",vec_b[x],vec_c[x],vec_g[x]);                  
    }
    
    system("pause");
    system("cls");

    printf("Matriz 1(prueba)\n\n");
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    printf("%d ",m1[x][y]);                  
    }
    printf("\n");                  
    }
    
    system("pause");
    system("cls");
    
    printf("Matriz 3\n\n");
 
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    m3[y][x]=m1[x][y];                  
    }                  
    }
    
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    printf("%d ",m3[x][y]);                  
    }    
    printf("\n");              
    }
    
    system("pause");
    system("cls");
    
    porcp=(contp/225)*100;
    porci=100.0-porcp;
    printf("\n\nPorcentaje de pares m2:%f\nPorcentaje de impares m2:%f\n",porcp,porci);
    
    system("pause");
    system("cls");
    
    printf("Matriz m1 con asteriscos \n\n");
    
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    if(m1[x][y]%2!=0){                  
    printf("%d  ",m1[x][y]);
    }else{
    printf("***  ");      
    }                  
    }         
    printf("\n");         
    }
    
    system("pause");
    system("cls");
    
    printf("Matriz 2(Con w,a,b)\n\n");
    
    for(x=0;x<15;x++){
    for(y=0;y<15;y++){
    if(x==y && x+y==14){
    printf("WWWW ");          
    }else if(x==y){
    printf("AAAA ");      
    }else if(x+y==14){
    printf("BBBB ");      
    }else{
    printf("%d ",m2[x][y]);      
    }
    }
    printf("\n\n");
    }
    system("pause");
    system("cls");
    
    system("PAUSE");
}
