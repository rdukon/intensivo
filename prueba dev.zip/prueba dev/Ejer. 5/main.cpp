#include <iostream>

int main() {
	
	float peson,diamn,res,contrec=0,contrec2=0,acumbs,contt=0,contp=0,conte=0,contn=0,porcent;
	
	do{
	contt++;
	
	printf("Ingrese el peso de la naranja(Gramos):");
	scanf("%f",&peson);
	
	printf("\n\nIngrese el diametro de la naranja(Centimetros):");
	scanf("%f",&diamn);
	
	if(peson>450 && diamn<=12 && diamn>=9){
		printf("\n\nEs una naranja de tipo premium");
		contp++;
		
	}else{
		if(peson<=450 && peson>=300 && diamn<=11 && peson>=8){
			printf("\n\nEs una naranja de tipo extra");
			conte++;
		}else{
			if(peson<300 && diamn<=9 && diamn>=7){
				printf("\n\nEs una naranja natural");
				contn++;
			}else{
				printf("\n\nEsta naranja fue rechazada");
				contrec++;
				contrec2++;
			}
		}
	}
	
	if(contrec2==12){
		contrec2=0;
		acumbs=acumbs-120;
	}
	if(contp==12){
		contp=0;
		acumbs=acumbs+200;
	}
	if(conte==12){
		conte=0;
		acumbs=acumbs+150;
	}
	if(contn==12){
		contn=0;
		acumbs=acumbs+120;
	}
	
	printf("\n\nDesea procesar otra naranja?\n1:Si\n2:No\n:");
	scanf("%f",&res);
	
	system("cls");
	
	}while(res==1);
	porcent=(contrec/contt)*100;
	
	printf("\n\nEl porcentaje de naranjas rechazadas fue de:%f %",porcent);
	
	printf("\n\nEl valor de la cosecha total fue de:%f Bs.",acumbs);
	
	return 0;
}
