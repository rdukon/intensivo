#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    int ct,cf,x=0,res,tct=0,tcf=0,menor=999999999;
    char pais[30],pmenor[30];
    
    do{
    x++;
    printf("\n\nIngrese el nombre del pais %d:",x);     
    fflush(stdin);     
    gets(pais);     
         
    printf("\n\nIngrese el total de casos registrados:");     
    scanf("%d",&ct);
    
    do{
    printf("\n\nIngrese el total de casos fatales,dentro del rango de casos registrados:");     
    scanf("%d",&cf);     
    }while(cf>ct || cf<0);      
    
    if(x>1){
    tct=tct+ct;
    tcf=tcf+cf;        
    }
    if(cf==0){
    printf("\n\nSu pais se encuentra en un estado de precaucion");          
    }else{
    printf("\n\nSu pais se encuentra en un estado de cuidado extremo");      
    }
    
    if(cf>0 && cf<=menor){
    strcpy(pmenor,pais);
    menor=cf;        
    }
    
    printf("\n\nDesea ingresar otro pais?\n1:Si\n2:No\n:");
    scanf("%d",&res);    
    }while(x<33 && res==1);
    
    printf("\n\nEl total de casos registrados fue de:%d\nY el total de casos fatales fue de:%d\n",tct,tcf);
    
    printf("El pais con el menor numero de casos fatales fue:%s\nCon un total de casos fatales de:%d",pmenor,menor);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
