#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char *argv[])
{
    
    char lista[5][30],aux[30];
    int x,y;
    
    for(x=0;x<5;x++){
                      
    printf("\n\nIngrese el nombre de la lista nro. %d\n:",x+1);
    fflush(stdin);
    gets(lista[x]);
    fflush(stdin);
        
    }
    printf("vector sin ordenar:\n\n");
    for(x=0;x<5;x++)
    {
         printf("%s\n",lista[x]);            
    }
                      
    for(x=0;x<5;x++)
    {
       for(y=0;y<x;y++)
       {
              //si lista[x]>lista[y] ---> intercambio
              if(strcmp(lista[x],lista[y])>0)
              {
                 //aux = lista[x]
                 strcpy(aux,lista[x]);
                 //lista[x]=lista[y]
                 strcpy(lista[x],lista[y]);
                 //lista[y] = aux 
                 strcpy(lista[y],aux);                          
              }         
       }
    }
    
    
    printf("vector ordenado de mayor a menor:\n\n");
    for(x=0;x<5;x++)
    {
         printf("%s\n",lista[x]);            
    }
        
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
