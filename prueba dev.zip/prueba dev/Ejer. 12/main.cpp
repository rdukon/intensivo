#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    char zona[40],ch,zonamayor[40];
    float ce,nump,prom,res,totalz,totalg=0,cont1=0,zmayor=0;
    int nhogar;
    
    do{
    printf("\n\nIngrese la zona a procesar:");
    fflush(stdin);
    gets(zona);
    
    totalz=0;
    for(nhogar=1;nhogar<=25;nhogar++){
    printf("\n\nIngrese el numero de personas del hogar %f:",nhogar);    
    scanf("%f",&nump);
    
    printf("\n\nIngrese el consumo electrico mensual:");
    scanf("%f",&ce);    
    
    totalz=totalz+ce;
        
    printf("\n\nIngrese la condicion habitacional\nP:Casa propia\nA:Alquilada\nM:Comodato\n:");
    fflush(stdin);
    scanf("%s",&ch);
    
    if(ch=='s'|| ch=='S' && ce>350.75){
    cont1++;             
    }
        
    prom=ce/nump;
    
    printf("\n\nEl promedio de consumo por persona es de:%f",prom);    
    }
    
    printf("\n\nEl total de Kw consumidos en esta zona fue de:%f",totalz);
    
    totalg=totalg+totalz;
    
    if(totalz>zmayor){
    zmayor=totalz;
    strcpy(zonamayor,zona);                  
    }
    
    printf("\n\nDesea procesar otra zona?\n1:Si\n2:No\n:");
    scanf("%f",&res);
    system("cls");
    }while(res==1);
    
    printf("\n\nEl total de Kw consumido a nivel general fue de:%f",totalg);
    
    printf("\n\nLa cantidad de zonas con consumo mayor a 350.75 fue de:%f",cont1);
    
    printf("La zona con el mayor consumo fue:%s\n",zmayor);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
