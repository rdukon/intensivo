#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <conio.h>
#include <string.h>
#define p 3.14159
int main()
{
 
 //credito de un banco
  
  float a,b,area1,area2,areat,r1,l1,per;
  
  printf("\nIngrese el valor de a"); 
  scanf("%f",&a);
  
  printf("\nIngrese el valor de b");
  scanf("%f",&b);
  
  area1=a*b;
  
  r1=a/2;
  
  area2=p*r1*r1;
  
  areat=area1+area2;
  
  l1=2*p*r1;
  
  per=(2*b+l1)/1000;
  
  if(areat>50000 && per>4 && per<=6.5){               
  printf("\nSe le aprobo el credito");                                           
  }
  else{     
  printf("\nNo se le aprobo el credito");      
  }
  
  //capacidad de ascensor
  
  /*float pesoa=106,pesop,contper,capa,r;
  
  printf("\nPor favor establezca la capacidad del ascensor,en toneladas:");
  scanf("%f",&capa);
  
  capa=capa*1000;
  
  contper=contper+2;
  
  printf("\nDesea procesar una persona?\n1:Si\n2:No\n:");
  scanf("%f",&r);
  
  while(r==1 && pesoa<capa){
             
  printf("\nIngrese el peso de la persona:");            
  scanf("%f",&pesop);            
   
  pesoa=pesoa+pesop;
  
  contper++;           
  
  if(pesoa<capa){
  printf("\nNo ha rebasado la capacidad maxima,desea ingresar otra persona?\n1:Si\n2:No\n:");
  scanf("%f",&r);                              
  }else{
  pesoa=pesoa-pesop;      
  contper--;      
  printf("\nHa rebasado la capacidad maxima");
  r=2;      
  } 
             
  }
  printf("\nEl peso dentro del ascensor fue de:%f \n Con %f personas\n",pesoa,contper);*/
  
  system("PAUSE");	
  return 0;
}
