#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    float porc,aux,deposito,res,resta;
    
    do{
    printf("Ingrese el total de litros del deposito,minimo 1500:");
    scanf("%f",&deposito);
    }while(deposito<1500);
    
    aux=deposito;
    
    printf("\n\nDesea abrir la valvula?\n1:Si\n2:No\n:");
    scanf("%f",&res);
    
    while(res==1 && deposito>0){
    
    do{
    printf("\n\nIngrese la cantidad que se dejo pasar por la valvula:");
    scanf("%f",&resta);              
    }while(resta>deposito);              
    deposito=deposito-resta;              
                  
    printf("\n\nLa cantidad de agua restante en el deposito es de:%f",deposito);
    
    if(deposito<1500 && deposito>=1150){
    printf("\n\nAdvertencia:Situacion estable en el deposito");                 
    }
    
    if(deposito<1150){
    printf("\n\nAdvertencia:Situacion de cuidado en el deposito");                  
    }
    
    printf("\n\nDesea abrir la valvula de nuevo?\n1:Si\n2:No\n:");              
    scanf("%f",&res);
    system("cls");                            
    }
    
    porc=(deposito/aux)*100;
    
    printf("\n\nLa cantidad de agua restante en el deposito es de:%f\nEl cual representa un porcentaje de:%f\n",deposito,porc);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
