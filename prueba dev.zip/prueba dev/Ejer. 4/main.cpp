/*#include <cstdlib>
#include <iostream>
#include <string.h>

int main(int argc, char** argv) {
	
	int r,conthom,sexo,contmuj,numprendas,contpant,contcamisas,x,tipoprenda,varmayor=0;
	char nom[40],nommayor[40];
	float peso;
	
	conthom=0;
	contmuj=0;
	
	printf("Un estudiante desea utilizar el servicio de lavanderia? 1: Si 2: No\n:");
	scanf("%d",&r);
	
	while(r==1){
		
		printf("\nIngrese el nombre");
		fflush(stdin);
		gets(nom);
		
		printf("\nIngrese el sexo 1:Masculino 2:Femenino\n:");
		scanf("%d",&sexo);
		
		if(sexo==2){
			contmuj++;
		}else{
			conthom++;
		}
			
		printf("\nIngrese el numero de prendas:");
		scanf("%d",&numprendas);
		
		contpant=0;
		contcamisas=0;
		
		for(x=0;x<numprendas;x++){
			
			printf("\nDescripcion de la prenda \n\n1:Pantalon \n\n2:Camisa \n\n3:Vestido \n\n4:Otro\n:");
			scanf("%d",&tipoprenda);
			
			if (tipoprenda==2){
				contcamisas++;
			}
			if(tipoprenda==1){
				contpant++;
			}
		}
		printf("\nLa cantidad total de camisas fue de:%d,y de pantalones fue de :%d",contcamisas,contpant);
		if(varmayor<=contpant && contcamisas>4 ){
			
			varmayor=contpant;
			strcpy(nommayor,nom);	
		}
		
		peso=((contpant*650)+(contcamisas*450))/1000;
		printf("\nEl peso total de camisas y pantalones juntos es de :%f",peso);
		
		printf("\nDesea procesar otro estudiante? 1:Si 2:No\n:");
		scanf("%d",&r);
	}
	
	if((conthom+contmuj)>0){
	
	if(varmayor!=0){
	printf("\nLa persona que trajo mas pantalones fue :%s ,con una cantidad de:%d pantalones",nommayor,varmayor);
	}
	if(conthom<contmuj){
		printf("\nLos hombres son los que utilizan menos la lavanderia\n");
	}else{
		if(contmuj<conthom){
		printf("\nLas mujeres son las que utilizan menos la lavanderia\n");	
		}
		else{
		printf("\nSe usa por igual la lavanderia,tanto para hombres como para mujeres\n");
		}
	}
	}
    system("PAUSE");
    return EXIT_SUCCESS;
}*/
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
   
   char sangre[3],sexo,nombre[40]; 
   int peso,contdia=1,edad,res;
   float contsa=0,contsb=0,contsab=0,contso=0,ltsa,ltsb,ltso,ltsab;
   
   do{
       printf("DIA #%d",contdia);
       contdia++;
        
       do{
       printf("\n\nIngrese su nombre:");            
       fflush(stdin);
       gets(nombre);            
                   
       printf("\n\nIngrese su sexo:");            
       fflush(stdin);
       scanf("%s",&sexo);            
       
       printf("\n\nIngrese su peso:");
       scanf("%d",&peso);
       
       printf("\n\nIngrese su edad:");
       scanf("%d",&edad);
       
       printf("\n\nIngrese su tipo de sangre:");
       fflush(stdin);
       scanf("%s",&sangre);
       
       if(sangre=='a'){
       contsa++;                
       }
       else{
            if(sangre=='b'){
            contsb++;                      
            }
            else{
                 if(sangre=='o'){
                 contso++;
                 }
                 else{
                 contsab++;      
                 }      
             }
       }
       
       if(edad>=18 && edad<=60 && peso>=50){
       printf("\n\nUsted es apto para donar sangre");           
       }else{
       printf("\n\nUsted no es apto para donar sangre");      
       }
       
       printf("\n\nDesea ingresar otra persona?\n1:Si\n2:No\n:");
       scanf("%d",&res);
                 
       }while(res==1);
       
       ltsa=contsa/2;
       ltsb=contsb/2;
       ltso=contso/2;
       ltsab=contsab/2;
       
       printf("\n\nEl total de litros de sangre A fue de:%f\n\nEl total de litros de sangre B fue de:%f\n\nEl total de litros de sangre O fue de:%f\n\nEl total de litros de sangre AB fue de:%f",ltsa,ltsb,ltso,ltsab);
       }while(contdia<=5);
   

    system("PAUSE");
    return EXIT_SUCCESS;
}
