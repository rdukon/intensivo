#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    int sala=0,serial,est,res,tot1,conts=0;
    float cont1,conti;
    
    do{
    sala++;    
    printf("\n\nSala %d",sala);
    
    cont1=0;
    conti=0;
    tot1=0;
    do{
    cont1++;
                 
    printf("\n\nIngrese el serial de la computadora:");
    scanf("%d",&serial);
    
    printf("\n\nIngrese el estado de la computadora\n1:Bueno\n2:Recuperable\n3:Inservible\n:");
    scanf("%d",&est);
    
    if(est==1 || est==2){
    tot1++;          
    }
    if(est==3){
    conti++;           
    }
    printf("\n\nDesea procesar otra computadora?\n1:Si\n2:No");
    scanf("%d",&res);
    }while(res==1);
    
    if((cont1/2)<conti){
    conts++;                  
    }
    
    printf("\n\nEl total de computadoras,entre buenas y recuperables,es de:%d",tot1);
    
    if(((tot1/cont1)*100)>=75){
    printf("\n\nEl laboratorio esta en una situacion mejorable");                           
    }else{
    printf("\n\nEl laboratorio esta en una situacion critica");      
    }
    
    }while(sala<16);
    
    printf("\n\nEl total de salas con mas de la mitad de las maquinas inservibles fue de:%d\n",conts);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
