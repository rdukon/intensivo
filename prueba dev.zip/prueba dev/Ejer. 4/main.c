#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
   
   char sangre,sexo,nombre[40],nombmenor[40]; 
   int peso,contdia=1,edad,res,pmenor=999999;
   float contsa,contsb,contsab,contso,ltsa,ltsb,ltso,ltsab,acum1,cont1=0,promp;
   
   do{    
       contsa=0;
       contsb=0;
       contso=0;
       contsab=0; 
       
       printf("\nDIA #%d",contdia);
       contdia++;
        
       do{
       printf("\n\nIngrese su nombre:");            
       fflush(stdin);
       gets(nombre);            
                   
       printf("\n\nIngrese su sexo(m/f):");            
       fflush(stdin);
       scanf("%s",&sexo);            
       
       printf("\n\nIngrese su peso:");
       scanf("%d",&peso);
       
       printf("\n\nIngrese su edad:");
       scanf("%d",&edad);
       
       printf("\n\nIngrese su tipo de sangre(a=Sangre A,b=Sangre B,o= Sangre O,c=Sangre AB)\n:");
       fflush(stdin);
       scanf("%s",&sangre);
       
       if(sangre=='a'){
       contsa++;                
       }
       if(sangre=='b'){
       contsb++;                      
       }
       if(sangre=='o'){
       contso++;
       }
       if(sangre=='c'){
       contsab++;      
       }      
       
       if(contdia>=2 && contdia<=4 && sexo=='m'){
       acum1=acum1+peso;
       cont1++;              
       }
       
       if(edad>=18 && edad<=60 && peso>=50){
       printf("\n\nUsted es apto para donar sangre");           
       }else{
       printf("\n\nUsted no es apto para donar sangre");      
       }
       
       if(peso<pmenor && sexo=='f'){
       pmenor=peso;
       strcpy(nombmenor,nombre);                  
       }
       
       printf("\n\nDesea ingresar otra persona?\n1:Si\n2:No\n:");
       scanf("%d",&res);
                 
       }while(res==1);
       
       
       ltsa=contsa/2;
       ltsb=contsb/2;
       ltso=contso/2;
       ltsab=contsab/2;
       
       printf("\n\nEl total de litros de sangre A por hoy fue de:%f\n\nEl total de litros de sangre B por hoy fue de:%f\n\nEl total de litros de sangre O por hoy fue de:%f\n\nEl total de litros de sangre AB por hoy fue de:%f",ltsa,ltsb,ltso,ltsab);
       }while(contdia<=5);
   
       promp=acum1/cont1;
       
       printf("\n\nEl promedio de peso de los donantes hombres entre Martes y Jueves fue de %f kilos\n",promp);
       
       printf("\nLa mujer con el menor peso fue %s,con un peso de %d kilos\n",nombmenor,pmenor);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
