#include <cstdlib>
#include <iostream>
#include <string.h>
using namespace std;

int main(int argc, char *argv[])
{
    
    char nombre[100],saludo[100];
    int x,y,z;
    
    do{
    printf("Ingrese la cantidad de saludos:");
    scanf("%d",&x);
        
    for(y=0;y<x;y++){
    printf("\n\nIngrese el nombre %d:",y+1);                 
    fflush(stdin);
    gets(nombre);
    fflush(stdin);                 
    
    for(z=4;z<=strlen(nombre);z++){
    saludo[z-4]=nombre[z];                                
    }                 
    printf("\n\nHola,%s",saludo);                 
                     
    }    
        
    system("pause");    
    system("cls");    
    
    }while(true);
    system("PAUSE");
    return EXIT_SUCCESS;
}
