#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char *argv[])
{
    int numerom,res;
    char codigom[4];
    
    
    printf("Ingrese la matricula\n:");
    scanf("%d %s",&numerom,&codigom);
    do{
    numerom++;
    if(numerom>9999)
    {
          numerom=0;
          codigom[2]++;          
    }
    if(codigom[2]=='A' || codigom[2]=='E' || codigom[2]=='I' || codigom[2]=='O' || codigom[2]=='U'){
    codigom[2]++;                   
    }
    if(codigom[2]>'Z'){
    codigom[1]++;
    codigom[2]='B';                   
    }
    
    if(codigom[1]=='A' || codigom[1]=='E' || codigom[1]=='I' || codigom[1]=='O' || codigom[1]=='U'){
    codigom[1]++;                   
    }
    if(codigom[1]>'Z'){
    codigom[0]++;
    codigom[1]='B';                   
    }
    if(codigom[0]=='A' || codigom[0]=='E' || codigom[0]=='I' || codigom[0]=='O' || codigom[0]=='U'){
    codigom[0]++;                   
    }
    
    if(numerom<10){              
    printf("\n000%d %s",numerom,codigom);              
    }else if(numerom<100){              
    printf("\n00%d %s",numerom,codigom);              
    }else if(numerom<1000){              
    printf("\n0%d %s",numerom,codigom);              
    }else{              
    printf("\n%d %s",numerom,codigom);              
    }  
    
    printf("\n\nDesea procesar la siguiente matricula?\n1:Si\n2:No\n:");
    scanf("%d",&res);
    system("cls");
    }while(res==1);
       
    system("PAUSE");
    return EXIT_SUCCESS;
}
