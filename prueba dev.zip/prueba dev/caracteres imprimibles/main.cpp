#include <cstdlib>
#include <iostream>
#include <windows.h>

using namespace std;

void textcolor(int color)
{
     HANDLE hcon;
     hcon = GetStdHandle(STD_OUTPUT_HANDLE);
     SetConsoleTextAttribute(hcon,color);
}

int main(int argc, char *argv[])
{
    int cont=1,j;
    for(int i=0;i<19;i++)
    {
         j=0;
         printf(" ");
         do
         {
             if(cont!=10 && cont!=0 && cont!=7 && cont!=8 && cont!=9 && cont!=13 && cont!=32 && cont!=247)
             {
                  if(cont<10)
                  {
                       printf("  %d:",cont); 
                       textcolor(9);
                       printf("%c ",cont); 
                       textcolor(7);    
                  }
                  else if(cont<100)
                  {
                       printf(" %d:",cont); 
                       textcolor(9);
                       printf("%c ",cont); 
                       textcolor(7);     
                  }
                  else if(cont<255)
                  {
                       printf("%d:",cont);  
                       textcolor(9);
                       printf("%c ",cont); 
                       textcolor(7);    
                  }
                  j++;       
             }
             cont++;
         } 
         while(j<13);  
         printf("\n");
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
