#include <stdlib.h>
#include <iostream.h>
#include <stdio.h>
#include <math.h>
#include <conio.h>
#include <string.h>

int main()
{
    
    float vel,distf,r,unt=150,multa,acum,promvel,contador,mayordistf,mayor,contveh,cont2,porcent;
    char placa[25],placamayor[25];
    
    do{
    
    contveh++;
    
    acum=0;
    contador=0;
    
    printf("Por favor ingrese la velocidad al momento del accidente:");                 
    scanf("%f",&vel);
    
    printf("\nPor favor ingrese la distancia de frenado:");                 
    scanf("%f",&distf);
    
    printf("\nPor favor ingrese la placa del vehiculo:");
    scanf("%s",&placa);
    
    if(distf>30){
    acum=acum+vel;
    contador++;
    }
    
    if(mayor<vel){
    strcpy(placamayor,placa);
    mayor=vel;
    mayordistf=distf;              
    }
    
    
    if(vel>100){
                           
    multa=(vel-100)*unt;
    printf("\n%s,se excedio de velocidad \nPor favor pagar un monto de :%f Bolivares",placa,multa);
    }else{ 
    
    cont2++;   
    printf("\nNo esta en necesidad de pagar una multa por exceso de velocidad");           
    }
    printf("\n\nDesea procesar otro vehiculo?\n 1:Si \n2:No");
    scanf("%f",&r);
    }while(r==1);
    
    printf("\nLa placa del vehiculo de mayor velocidad fue de %s\n Con una distancia de frenado de %f",placamayor,mayordistf);
    
    promvel=acum/contador;
    
    printf("\n\nLa velocidad promedio con +30 mtrs. de frenado fue de %f",promvel);
    
    porcent=(cont2/contveh)*100;
    
    printf("\nEl porcentaje de gente que no tuvo multa fue de:%f",porcent);
    
    system("pause");
    return 0;
}
