#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    int num,exp=0,primo=2,salida=1;
    
    printf("Ingrese el numero del ejercito:");
    scanf("%d",&num);
    
    do{
    if(num%primo==0){
    exp++;
    num=num/primo;                 
    }else{
    primo++;      
    salida=salida*(exp+1);      
    exp=0;      
    }
    }while(num>=primo);
    salida=salida*(exp+1);
    
    printf("\n:%d",salida);
    
    
    
    
    
    
    
    
    
    
    
    
     
    system("PAUSE");
    return EXIT_SUCCESS;
}
