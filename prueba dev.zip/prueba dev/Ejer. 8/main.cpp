#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    char pais[30];
    int dias,x,res,cont;
    float acumt=0,acum1,temp,prom1,promt,diast=0,temp2;
    
    do{
    printf("\n\nIngrese el nombre del pais:");
    fflush(stdin);
    gets(pais);
    
    printf("\n\nIngrese la cantidad de dias que hizo la prueba:");
    scanf("%d",&dias);
    
    diast=diast+dias;
    
    acum1=0;
    
    for(x=1;x<=dias;x++){
    printf("\n\nIngrese la temperatura del dia %d:",x);
    scanf("%f",&temp);                    
    acum1=acum1+temp;
    if(temp>105 && x>1 && x<(dias-1)){
    cont++;            
    }                    
    }
    
    acumt=acumt+acum1;
    
    prom1=acum1/dias;
    printf("\n\nEl promedio de temperatura del pais es de:%f",prom1);
    
    printf("\n\nLa cantidad de dias que la temperatura rebaso los 105 grados fue de:%d",cont);
    
    printf("\n\nDesea procesar otro pais?\n1:Si\n2:No");
    scanf("%d",&res);
    }while(res==1);
    
    promt=acumt/diast;
    printf("\n\nEl promedio de temperatura a nivel global fue de:%f",promt);
    
    printf("Ingrese la temperatura promedio del a�o pasado");
    scanf("%f",&temp2);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
