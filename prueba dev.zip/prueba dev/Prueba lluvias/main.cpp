#include <cstdlib>
#include <iostream>
#include <string.h>
using namespace std;

int main(int argc, char *argv[])
{
    char ciudad[20][40];
    float dato[20][5],vecc[20],vecm[5],acum=0,mes_max=0,minciu=999999999;
    int i,aux_mes=-1,contc=0,res,x,pos_ciu;
    
    do{
    printf("\n\nIngrese el nombre de la ciudad:");
    fflush(stdin);
    gets(ciudad[contc]); 
    fflush(stdin);
     
    for(i=0;i<5;i++)
    {
    vecm[i]=0;                     
    printf("\n\nIngrese la cantidad de lluvia para el mes:%d,de la ciudad %s:",i+1,ciudad[contc]);
    scanf("%f",&dato[contc][i]);
    acum=acum+dato[contc][i];                        
    }
    printf("\nDesea ingresar otra ciudad?\n1:Si\n2:No\n:");
    scanf("%d",&res);
    vecc[contc]=0;
    contc++;    
    }while(res==1 && contc<20);
    //===============================================================================================    
    for(x=0;x<contc;x++)
    {
    for(i=0;i<5;i++){
          vecc[x]=vecc[x]+dato[x][i];
          vecm[i]=vecm[i]+dato[x][i];           
    }                                          
    }
    
    for(x=0;x<contc;x++)
    {
         vecc[x]=vecc[x]/5;               
    }
    
    for(i=0;i<5;i++)
    {
         vecm[i]=vecm[i]/contc;               
    }
    //================================================================================================
    
    //calculo de mes maximo y ciudad con menos lluvia
    
    for(i=0;i<5;i++)
    {
         if(vecm[i]>mes_max)
         {
               mes_max=vecm[i];
               aux_mes=i;             
         }               
    }
    
    for(x=0;x<contc;x++)
    {
         if(vecc[x]<minciu){
         minciu=vecc[x];
         pos_ciu=x;                   
         }               
    }
    //-------------------------------------------------------------------------------------------------
    for(x=0;x<contc;x++){
    printf("\nCiudad %s:",ciudad[x]); 
    for(i=0;i<5;i++){
    printf(" %f",dato[x][i]);                 
    }  
    printf("\nPromedio:%f\n",vecc[x]);                  
    }
    for(i=0;i<5;i++){
    printf("\nPromedio mes %d: %f \n",i+1,vecm[i]);                 
    }
    
    printf("\n\nTotal lluvias=%f",acum);
    
    printf("\n\nEl mes que cayo mas lluvia fue:%d\nCon un promedio de:%f",aux_mes,mes_max);
    
    printf("\n\nLa ciudad que registro menor lluvia fue:%s\ncon un promedio de:%f\n",ciudad[pos_ciu],minciu);
    system("PAUSE");
    return EXIT_SUCCESS;
}
                    
