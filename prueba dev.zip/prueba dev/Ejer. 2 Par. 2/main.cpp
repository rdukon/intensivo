#include <cstdlib>
#include <iostream>
#include <string.h>
#include <time.h>
using namespace std;

int main(int argc, char *argv[])
{
    char texto[300],textoaux[300];
    int x,cpal=0,tam,vrand;
    float contv=0,porcv,contd=0,contl=0,porcd,porcl;
    
    srand(time(NULL));
    
    printf("Texto(300 caracteres)\n:");
    fflush(stdin);
    gets(texto);
    fflush(stdin);
    
    tam=strlen(texto);
    
    for(x=0;x<strlen(texto);x++){
    if(texto[x]=='a' || texto[x]=='A' || texto[x]=='e' || texto[x]=='E' || texto[x]=='i' || texto[x]=='I' || texto[x]=='o' || texto[x]=='O' || texto[x]=='u' || texto[x]=='U')
    {
    contv++;
    }                             
    }
    
    porcv=(contv/tam)*100;
    
    printf("\n\nEl porcentaje de vocales es de:%f",porcv);
    
    for(x=0;x<tam;x++){
    if(texto[x]!=' ' &&(texto[x+1]==' ' || texto[x+1]=='\0')){
    cpal++;               
    }
    }
    
    printf("\n\nEl total de palabras es de:%d",cpal);
    
    for(x=0;x<strlen(texto);x++){
    if(isdigit(texto[x])>0){
    contd++;
    }   
    if(isalpha(texto[x])>0){
    contl++;
    }                          
    }
    
    porcd=(contd/tam)*100;
    porcl=(contl/tam)*100; 
    
    printf("\n\nPorcentaje de digitos:%f\nPorcentaje de letras:%f",porcd,porcl);
    
    for(x=0;x<tam;x++){
    if(texto[x]==' '){
    texto[x]='_';               
    }               
    }
    
    printf("\n\nTexto con _\n:%s\n",texto);
    
    for(x=tam-1;x>=0;x--){
    printf("%c",texto[x]);                     
    }
    printf("\n");
    
    for(x=0;x<tam;x++){
    vrand=rand()%10;
    textoaux[x]=texto[x]+vrand;                   
    }
    printf("\n\n%s\n",textoaux);
    system("PAUSE");
    return EXIT_SUCCESS;
}
