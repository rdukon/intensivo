#include <cstdlib>
#include <iostream>

using namespace std;

void mostrar(int mat[10][10])
{
    int i,j;
    
    printf("\n");
    for(i=0;i<10;i++)
    {
         printf("\t");
         for(j=0;j<10;j++)
         {
                if(mat[i][j]==0)
                {
                   printf("%c",'.');             
                } 
                else
                {
                   printf("%c",219); 
                }        
         }
         printf("\n");           
    }
    printf("\n");
}

int contar_vecinas(int mat[10][10],int x, int y)
{
    int vecinas=0;
    if(x>0 && y>0)
    {
       vecinas=vecinas+mat[x-1][y-1];
    }
    if(x>0)
    {
       vecinas=vecinas+mat[x-1][y];
    }
    if(x>0 && y<9)
    {
       vecinas=vecinas+mat[x-1][y+1];
    }
    if(y<9)
    {
       vecinas=vecinas+mat[x][y+1];
    }
    if(x<9 && y<9)
    {
       vecinas=vecinas+mat[x+1][y+1];
    }
    if(x<9)
    {
       vecinas=vecinas+mat[x+1][y];
    }
    if(x<9 && y>0)
    {
       vecinas=vecinas+mat[x+1][y-1];
    }
    if(y>0)
    {
       vecinas=vecinas+mat[x][y-1];
    }
    return vecinas;
}

void reglas(int mat[10][10])
{
    int i,j,mat_aux[10][10];
    
    for(i=0;i<10;i++)
    {
         for(j=0;j<10;j++)
         {
              if(mat[i][j]==0 && contar_vecinas(mat,i,j)==3)
              {
                   mat_aux[i][j]=1;           
              }            
              else if(mat[i][j]==1 && (contar_vecinas(mat,i,j)<2 || contar_vecinas(mat,i,j)>3))
              {
                   mat_aux[i][j]=0;            
              }
              else
              {
                  mat_aux[i][j]=mat[i][j];
              }
         }
    }
    
    for(i=0;i<10;i++)
    {
         for(j=0;j<10;j++)
         {
              mat[i][j]=mat_aux[i][j];           
         }
    }
}

int main(int argc, char *argv[])
{
    
    int cont=0,resp,mat[10][10]={{0,0,0,0,0,0,0,0,0,0},
                                 {0,0,0,0,0,0,0,0,0,0},
                                 {0,0,0,0,0,0,0,0,0,0},
                                 {0,0,0,0,0,0,0,0,0,0},
                                 {0,0,0,0,0,0,0,0,0,0},
                                 {0,0,0,0,0,0,0,0,0,0},
                                 {0,0,0,0,0,0,1,1,1,0},
                                 {0,0,0,0,0,0,1,0,0,0},
                                 {0,0,0,0,0,0,0,1,0,0},
                                 {0,0,0,0,0,0,0,0,0,0}};
    
    
    do
    {
        system("cls");
        printf("ETAPA %d\n",cont);                       
        mostrar(mat);
        reglas(mat);
        printf("\n");
        printf("\ndesea continuar? 1=si, 2=no: ");
        scanf("%d",&resp);
        cont++;
    }while(resp==1);        
}
