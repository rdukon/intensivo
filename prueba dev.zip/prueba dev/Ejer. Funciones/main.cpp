#include <cstdlib>
#include <iostream>

using namespace std;


void operaciones(int a, int b);


int suma(int a, int b);


int resta(int a, int b);


int multiplicacion(int a, int b);


int main(int argc, char *argv[])
{
    int a,b,resp; 
    do
    {
         system("cls");
         printf("Ingrese 2 numeros: ");
         scanf("%d %d",&a,&b); 
         
         operaciones(a,b);
         
         printf("\n desea hacer mas operaciones? 1=si, 2=no: ");
         scanf("%d",&resp);
              
    }while(resp==1);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}

void operaciones(int a, int b)
{
    int val;
    val=suma(a,b);
    printf("\n\nla suma es: %d",val); 
    val=resta(a,b);
    printf("\n\nla resta es: %d",val); 
    val=multiplicacion(a,b);
    printf("\n\nla multiplicacion es: %d",val); 
}

int suma(int a, int b)
{
    int s;
    s=a+b;
    return s;
}

int resta(int a, int b)
{
    int r;
    r=a-b;
    return r;
}

int multiplicacion(int a, int b)
{
    int m;
    m=a*b;
    return m;
}

