#include <cstdlib>
#include <iostream>
#include <conio.h>
#include <windows.h>

using namespace std;

int main(int argc, char *argv[])
{
    char resp=' ';
    do
    {
         system("cls");
         if(kbhit())
         {
            resp=getch();
         }
         printf("\nUltima tecla: %c",resp);
         Sleep(500);
         
    }while(resp!='a');
}
