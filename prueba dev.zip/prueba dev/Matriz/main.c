#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	 
	int x,f,y;
	int matriz [f][f];
	
	printf("Ingrese tama�o de la matriz:");
	scanf("%d",&f);
	
	srand(time(0));
	
	for(x=0;x<=f;x++){
		matriz[x][x]=rand()%80+20;
	}
	
	for (x=0;x<=f;x++){	
	printf("\n\nD1=%d",matriz[x][x]);	
	}
	/*y=f;
	for(x=0;x<=f;x++){
		y--;
		printf("\n\nD2=%d",matriz[x])
	}
	*/
	return 0;
}
