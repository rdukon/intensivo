#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char *argv[])
{
    int x,num,y;
    char linea[100],nombre[100];
    
    printf("Ingrese el numero de personas que saludaron:");
    scanf("%d",&num);
    
    for(x=0;x<num;x++){
    printf("\n\nIngrese el saludo %d:",x+1);
    fflush(stdin);
    gets(linea);
    fflush(stdin);
    for(y=4;y<strlen(linea);y++){
    nombre[y-4]=linea[y];                             
    }                   
    nombre[y-4]='\0';
    printf("\n\nHola, %s.",nombre);
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
