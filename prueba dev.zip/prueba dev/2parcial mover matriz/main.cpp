#include <cstdlib>
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <time.h>

#define M 8

#define ARRIBA 72
#define ABAJO 80
#define IZQUIERDA 75
#define DERECHA 77

using namespace std;

void textcolor(int color)
{
     HANDLE hcon;
     hcon = GetStdHandle(STD_OUTPUT_HANDLE);
     SetConsoleTextAttribute(hcon,color);
}

void gotoxy(int x, int y)
{
     HANDLE hcon;
     hcon = GetStdHandle(STD_OUTPUT_HANDLE);
     COORD dwPos;
     dwPos.X = x;
     dwPos.Y = y;
     SetConsoleCursorPosition(hcon,dwPos);
}

void llenar(int m1[M][M]){
    
    int x,y;
     
    srand(time(0));
    
    for(x=0;x<M;x++){
    for(y=0;y<M;y++){
    
    m1[x][y]=rand()%10;
                     
    }                 
    }  
}
void pintar_sub(int posX,int posY,int subm[3][3]){
     
     int a,b,x,y;
     
     textcolor(12);
     a=posX-1;
     for(x=0;x<3;x++){
     b=posY-1;
     for(y=0;y<3;y++){
     gotoxy(17+2*b,1+2*a);
     if(a==posX && b==posY){
     printf("*");          
     }else{
     printf("%d",subm[x][y]);
     }
     b++;                 
     }                 
     a++;                 
     }
     textcolor(7);
     gotoxy(17+2*posY,1+2*posX);
}

void matriz(int m1[M][M]){

    int x,y,posX=1,posY=1,selec=0,a,b,subm[3][3];
    char resp;
     
    do{
    system("cls");           
    
    printf("\n");
    for(x=0;x<M;x++){
    printf("\t\t");                
    for(y=0;y<M;y++){
    
    printf(" %d",m1[x][y]);
                     
    }                 
    printf("\n\n");
    }
    printf("\nDesplace el cursor con las flechas direccionales");
    printf("\n\nSeleccione una matriz con la tecla <<s>>");
    printf("\n\nVuelva al estado original con la tecla <<t>>");
    printf("\n\nPara Salir presione la tecla <<x>>");
    
    gotoxy(17+2*posY,1+2*posX);
    if(selec==1){
    pintar_sub(posX,posY,subm);             
    }
    resp=getch();
    
    switch(resp)
    {
           case ARRIBA:    if(posX>1)
                           {
                              posX--;
                           }
                           break;
           case ABAJO:     if(posX<M-2)
                           {
                              posX++;
                           }
                           break;
           case IZQUIERDA: if(posY>1)
                           {
                               posY--;
                           }
                           break;
           case DERECHA:   if(posY<M-2)
                           {
                              posY++;
                           }
                           break;
           case 's':       selec=1;
                           a=posX-1;
                           for(x=0;x<3;x++){
                           b=posY-1;
                           for(y=0;y<3;y++){
                           subm[x][y]=m1[a][b];
                           b++;                 
                           }                 
                           a++;                 
                           }
                           break;
           case 't':       selec=0;
                           /*a=posX-1;
                           for(x=0;x<3;x++){
                           b=posY-1;
                           for(y=0;y<3;y++){
                           m1[a][b]=subm[x][y];
                           b++;                 
                           }                 
                           a++;                 
                           }*/
                           break;                                      
    }
    }while(resp!='x');
        
}



int main(int argc, char *argv[])
{
    int m1[M][M];

    llenar(m1);
             
    matriz(m1);
    
    return 0;
}

