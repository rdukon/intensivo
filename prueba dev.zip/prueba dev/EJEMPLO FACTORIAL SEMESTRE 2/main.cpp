#include <cstdlib>
#include <iostream>

using namespace std;


int factorial(int num)
{
    int x,fact=1;
    for(x=1;x<=num;x++)
    {
         fact=fact*x;              
    }
    return fact;
}

float potencia(float base, int exp)
{
      int x;
      float pot=1.0;
      for(x=0;x<exp;x++)
      {
            pot=pot*base;            
      }
      return pot;
}

float raiz(float base)
{
      float li,ls,lm;
      li=1;
      ls=base/2;
      if(base<4)
      {
          li=ls;
          ls=base;      
      }
      while((int)(li*1000000)!=(int)(ls*1000000))
      {          
           lm=(li+ls)/2; 
           if(potencia(lm,2)>base)
           {
               ls=lm;                 
           }           
           else
           {
               li=lm;
           }              
      }
      return ls;
}

int main(int argc, char *argv[])
{
    
    printf("\n\n%f\n",raiz(2));
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
