#include <cstdlib>
#include <iostream>
#include <time.h>
using namespace std;
#define N 5
#define M 10
void arreglo(int val){

if(val<10){
printf("00%d ",val);     
}else if(val<100){
printf("0%d ",val);      
}else{
printf("%d ",val);      
}
}

int main(int argc, char *argv[])
{
    int a[N][N],b[N][N],c[N][N],x,y;
    int d[M][M],e[M][M],f[M][M],z,acum,p;
   
    srand(time(0));
   
    for(x=0;x<N;x++){
    for(y=0;y<N;y++){
    a[x][y]=rand()%1000;                 
    }                 
    }
    
    for(x=0;x<N;x++){
    for(y=0;y<N;y++){
    arreglo(a[x][y]);                 
    } 
    printf("\n");                
    }
    
    printf("\n\n");
    
    for(x=0;x<N;x++){
    for(y=0;y<N;y++){
    b[x][y]=a[N-1-x][N-1-y];
    if(x==(N-1)/2 || y==(N-1)/2){
    printf("*** ");              
    }else{
    arreglo(b[x][y]);      
    }             
    }  
    printf("\n");      
    }
    
    for(x=0;x<N;x++){
    for(y=0;y<N;y++){
    if(a[x][y]%2==0){
    c[x][y]=-1;       
    }else{
    c[x][y]=a[x][y];
    }          
    }                 
    }
    
    printf("\n\n");
    
    for(x=0;x<N;x++){
    for(y=0;y<N;y++){
    if(c[x][y]==-1){
    printf("--- ");               
    }else{
    arreglo(c[x][y]);      
    }                 
    }                
    printf("\n"); 
    }
    
    system("pause");
    system("cls");
    
    for(x=0;x<M;x++){
    for(y=0;y<M;y++){
    d[x][y]=rand()%10; 
    e[x][y]=rand()%10;             
    }                 
    }
    
    for(x=0;x<M;x++){
    for(y=0;y<M;y++){
    acum=0;
    for(z=0;z<M;z++){
    p=d[x][z]*e[z][y];
    acum=acum+p;
    }           
    f[x][y]=acum;  
    }                 
    }
    
    for(x=0;x<M;x++){
    for(y=0;y<M;y++){
         printf("%d ",d[x][y]);            
    }
    printf("\n"); 
    }
    
     printf("\n\n");
    
    for(x=0;x<M;x++){
    for(y=0;y<M;y++){
         printf("%d ",e[x][y]);            
    }
    printf("\n"); 
    }
    
     printf("\n\n");
    
    for(x=0;x<M;x++){
    for(y=0;y<M;y++){
    printf("%d ",f[x][y]);             
    }          
    printf("\n");       
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
