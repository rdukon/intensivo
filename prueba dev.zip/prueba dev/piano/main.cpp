#include <cstdlib>
#include <iostream>

using namespace std;

int traducir_nota(char nota[5]);

int main(int argc, char *argv[])
{
    char nota[6];
    int z,y,x,piano[84],menor=85,mayor=-1;
    
    for(x=0;x<84;x++){
    piano[x]=0;                  
    } 
    
    printf("Ingrese la cantidad de notas:");
    scanf("%d",&z);
    
    for(x=0;x<z;x++){
         printf("\n\nIngrese la nota %d:",x+1);
         scanf("%s",&nota);
    
         y=traducir_nota(nota);
    
         piano[y]++;
    
         if(y<menor){
         menor=y;                   
         }
    
         if(y>mayor){
         mayor=y;                   
         }
    }
    
    x=0;
    printf("\n");
    for(x=menor;x<=mayor;x++){
    
         printf("%d ",piano[x]);            
                      
    }
    
    printf("\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
int traducir_nota(char nota[5]){
    
    int x,tam,oct;
    
    if(nota[0]=='d'){
    x=0;                 
    }
    if(nota[0]=='r'){
    x=2;                 
    }
    if(nota[0]=='m'){
    x=4;                 
    }
    if(nota[0]=='f'){
    x=5;                 
    }
    if(nota[0]=='l'){
    x=9;                 
    }
    if(nota[0]=='s'){
         if(nota[1]=='o'){
         x=7;                 
         }else{
         x=11;      
         }                 
    }
    
    if(nota[2]=='#'|| nota[3]=='#'){
    x++;                  
    }
    if(nota[2]=='b'|| nota[3]=='b'){
    x--;                  
    }
    
    tam=strlen(nota);
    
    oct=nota[tam-1]-48;
    
    oct=(oct-1)*12;
    x=x+oct;
    return x;    
}


