#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char *argv[])
{
    char minas[20][20];
    int i,j,fil,col,cont1,cont2=0;
    
    printf("Ingrese la cantidad de filas: ");
    scanf("%d",&fil);
    
    for(i=0;i<fil;i++)
    {
         printf("\nIngrese la fila %d: ",i+1);
         scanf("%s",minas[i]);             
    }
    
    col=strlen(minas[0]);
    printf("\nla cantidad de columnas es: %d\n",col);
    
    for(i=0;i<fil;i++)    
    {
          for(j=0;j<col;j++)
          {
              if(minas[i][j]=='*')
              {
              cont1++;
              } 
              else
              {
              cont2++;
              }             
          }                   
    }
    
    printf("\n\nEl total de minas es de:%d\nY el de celdas vacias es de:%d\n",cont1,cont2);
        system("pause");
}
