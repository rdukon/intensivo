#include <cstdlib>
#include <iostream>
#include <windows.h>
#include <conio.h>

using namespace std;

void textcolor(int color)
{
     HANDLE hcon;
     hcon = GetStdHandle(STD_OUTPUT_HANDLE);
     SetConsoleTextAttribute(hcon,color);
}

void gotoxy(int x, int y)
{
     HANDLE hcon;
     hcon = GetStdHandle(STD_OUTPUT_HANDLE);
     COORD dwPos;
     dwPos.X = x;
     dwPos.Y = y;
     SetConsoleCursorPosition(hcon,dwPos);
}

int main(int argc, char *argv[])
{
    textcolor(9);
    gotoxy(10,10);
    printf("hola");
    gotoxy(10,11);
    printf("hola");
    gotoxy(10,12);
    printf("hola");
    textcolor(12);
    gotoxy(10,9);
    printf("hola");
    getch();
    return EXIT_SUCCESS;   
}
