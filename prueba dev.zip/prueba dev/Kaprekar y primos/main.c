#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[])
{
  
  int num,aux,aux1=1,aux2=0,ult,com=10;
  
  printf("Ingrese un numero el cual desee comprobar como krapekar");
  scanf("%d",&num);
  
  aux=num*num;
  
  while(aux1>0 && aux2!=aux){
          
  ult=aux%com;                
  aux=aux/com;               
  aux2=aux+ult;
  if(aux2!=aux){
  com*10;              
  }
    
  }
  if(aux2=aux){            
  printf("Es un numero krapekar");                          
  }else{
        if(aux1<10 && aux2!=aux){           
                   printf("No es un numero krapekar");                      
                   }    
        }
  system("PAUSE");	
  return 0;
}
 /* int i,primo;
  
  printf("Numeros primos menores que 1000:\n\n");
  
  for(i=2;i<1000;i++)
  {
       primo=2;
       while(i>primo && i%primo!=0)
       {
          primo++;
       }          
       if(i==primo)
       {
          printf("\n%d ",i);        
       }     
  }
  
  printf("\n");
  system("pause");
}
*/
