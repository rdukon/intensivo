#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    char nombre[30],nommayor[30];
    int librose,cde,ug,res,totall=0,totalcd=0,mayor=-1;
    float precioc,descuento,aux,dprom,cont1=0,acumd=0;
    
    printf("Desea procesar una persona?\n1:Si\n2:No\n:");
    scanf("%d",&res);
    
    while(res==1){
    cont1++;
    
    printf("\nIngrese su nombre:");
    fflush(stdin);
    gets(nombre);
    
    printf("\n\nIngrese el total de libros que desea:");
    scanf("%d",&librose);

    totall=totall+librose;
    
    printf("\n\nIngrese el total de CDs que desea:");
    scanf("%d",&cde);
    
    totalcd=totalcd+cde;
    
    printf("\n\nIngrese su ubicacion geografica\n1:Occidente\n2:Oriente\n3:Centro\n:");
    scanf("%d",&ug);    
    
    aux=(librose+cde)*2;
    descuento=(((librose*75)+(cde*45))*aux)/100;
    precioc=((librose*75)+(cde*45))-descuento;
    
    acumd=acumd+aux;
    
    printf("\n\nEl costo de la compra total es de:%f",precioc);
    
    if(librose>3 || cde>3){
    printf("\n\nSu envio es gratis");             
    }else{
          if(ug==1){
          printf("\n\nSu envio tiene un costo de 45 Bs.");          
          }else{
                if(ug==2){
                printf("\n\nSu envio tiene un costo de 35 Bs.");          
                }else{
                printf("\n\nSu envio tiene un costo de 25 Bs.");      
                }      
          }
    }
    
    if(cde>mayor && librose==0){
    mayor=ug;   
    strcpy(nommayor,nombre);                          
    }
   
    
    printf("\n\nDesea procesar otra persona?\n1:Si\n2:No\n:");
    scanf("%d",&res);
    system("cls");
    }
    
    if(mayor==-1){
       printf("\n\nNo se puede mostrar la persona que compro mas CDs");           
    }
    if(mayor==1){
       printf("\n\nLa persona que mas CDs compro fue %s,de la region Occidente",nommayor);          
    }
    if(mayor==2){
       printf("\n\nLa persona que mas CDs compro fue %s,de la region Oriente",nommayor);          
    }
    if(mayor==3){
       printf("\n\nLa persona que mas CDs compro fue %s,de la region Centro",nommayor);          
                 
    }
    
    dprom=acumd/cont1;
    printf("\n\nEl descuento promedio es de:%f",dprom);
    
    printf("\n\nEl total de libros fue de:%d\n\nY el total de CDs fue de:%d\n",totall,totalcd);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
