#include <cstdlib>
#include <iostream>
#include <time.h>

using namespace std;

int main(int argc, char *argv[])
{
    /*int m1[30],x,m2[30],aux,y;
    
    srand(time(0));
    
    for(x=0;x<30;x++){
                      
    m1[x]=rand()%900+100;                  
                      
    }
    
    for(x=0;x<30;x++){
                      
    m2[x]=m1[x];                  
                      
    }
    
    for(x=0;x<30;x++){
    for(y=0;y<x;y++){
    if(m2[x]<m2[y]){
    aux=m2[x];                
    m2[x]=m2[y];
    m2[y]=aux;               
    }                 
    }                  
    }
    
    for(x=0;x<30;x++){
                      
    printf("%d      %d\n",m1[x],m2[x]);                  
                      
    }
    */
//-------------------------------------------    
    int x,y,j,m1[30],m2[30],m3[60];
    
    srand(time(0));
    
    for(x=0;x<30;x++){
    
    m1[x]=(rand()%450+50)*2;
    m2[x]=((rand()%450+50)*2)+1;
                      
    }
    
    for(x=0;x<30;x++){
    m3[j]=m1[x];
    j++;                  
    m3[j]=m2[x];
    j++;              
    }
    
    
    for(x=0;x<30;x++){
    printf("%d        %d\n",m1[x],m2[x]);                  
    }
    
    system("pause");
    
    printf("\n\n");
    
    for(x=0;x<60;x++){
    printf("%d\n",m3[x]);
    if(x%10==0){
    printf("\n");
    system("pause");            
    }                  
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
