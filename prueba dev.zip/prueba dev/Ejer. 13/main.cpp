#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    int cod,reb,res;
    float alt,cont1=0,contr=0,porc,cont2=0;
    
    printf("\nDesea procesar un balon?\n1:Si\n2:No\n");
    scanf("%d",&res);
    
    while(res==1){
    cont1++;
    printf("\n\nIngrese el codigo del balon:");
    scanf("%d",&cod);
    
    printf("\n\nIngrese la altura de caida,metros:");
    scanf("%f",&alt);
    
    printf("\n\nIngrese la altura de rebote,centimetros:");
    scanf("%d",&reb);
    
    if(alt>1){  
          if(reb>58 && reb<74){
          printf("\n\nEl balon fue aceptado");          
          }else{
          printf("\n\nEl balon fue rechazado");
          contr++;      
          }
    }else{
          if(reb>=35 && reb<=55){
          printf("\n\nEl balon fue aceptado");           
          }else{
          printf("\n\nEl balon fue rechazado");
          contr++;      
          }      
    }
    
    if(alt>1 && reb==66){
    printf("\n\nEl balon %d,esta aprobado para la final");
    cont2++;         
    }
    printf("\n\nDesea procesar otro balon?\n1:Si\n2:No\n:");
    scanf("%d",&res);
    system("cls");
    }
    
    porc=(contr/cont1)*100;
    printf("\n\nEl porcentaje de balones rechazados fue de:%f \n",porc);
    
    printf("\n\nEl total de balones que se puede usar en la final es de:%f",cont2);
 
    system("PAUSE");
    return EXIT_SUCCESS;
}
