#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{

    int cont=0,num,rev=0,ult,aux,d1,d2,d3,d4,d_aux;
    
    do{
    printf("Ingrese numero de 4 digitos");
    scanf("%d",&num);
    }while(num<1000 || num>=10000);  
    
    
    
    if(num%1111!=0)
    {
               
    while(num!=6174)
    {               
       
       d1=num/1000;
       d2=(num/100)%10;
       d3=(num/10)%10;
       d4=num%10;
       
       
       // ordenando digitos de mayor a menor
       if(d1<d2)
       {
           d_aux=d1;
           d1=d2;
           d2=d_aux;      
       }
       
       if(d2<d3)
       {
           d_aux=d2;
           d2=d3;
           d3=d_aux;      
       }
       
       if(d3<d4)
       {
           d_aux=d3;
           d3=d4;
           d4=d_aux;      
       }
       
       if(d1<d2)
       {
           d_aux=d1;
           d1=d2;
           d2=d_aux;      
       }
       
       if(d2<d3)
       {
           d_aux=d2;
           d2=d3;
           d3=d_aux;      
       }
       
       if(d1<d2)
       {
           d_aux=d1;
           d1=d2;
           d2=d_aux;      
       }
       /////////////
       
       num = d1*1000+d2*100+d3*10+d4;
       
       aux=num;             
       while(aux>0){             
          ult=aux%10;
          rev=rev*10+ult;                        
          aux=(aux-ult)/10; 
          }      
        num=num-rev;
        rev=0;
        cont++;
     } 
     
     printf("\n\nel numero de repeticiones es : %d\n",cont);
     system("pause");
    }
    
}
