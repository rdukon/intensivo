#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char nombre[10][30];
    int edad[10],i,mayor=0,pos1=-1,pos2=-1;
    
    for(i=0;i<10;i++)
    {                
        printf("Ingrese el nombre de la persona %d: ",i+1);
        scanf("%s",nombre[i]);
        printf("\nIngrese la edad de la persona %d: ",i+1);
        scanf("%d",&edad[i]);             
    }
    
    /////////////////////////////////////////////////
    // CASO 1: nombre de la persona con mayor edad, si son varias mostrar la PRIMERA
    
    for(i=0;i<10;i++)
    {
        if(edad[i]>mayor)
        {
              mayor=edad[i]; 
              pos1=i;          
        }             
    }
    
    printf("\n\nCASO 1: la persona con mayor edad es: %s",nombre[pos1]);
    
    /////////////////////////////////////////////////
    
    // CASO 2: nombre de la persona con mayor edad, si son varias mostrar la ULTIMA
    
    for(i=0;i<10;i++)
    {
        if(edad[i]>=mayor)
        {
              mayor=edad[i]; 
              pos2=i;          
        }             
    }
    
    printf("\n\nCASO 2: la persona con mayor edad es: %s",nombre[pos2]);
    
    /////////////////////////////////////////////////
    
    // CASO 3: nombre de la persona con mayor edad, si son varias mostrar TODAS
    
    for(i=0;i<10;i++)
    {
        if(edad[i]>mayor)
        {
              mayor=edad[i];        
        }             
    }
    
    printf("\n\nCASO 3: Listado de personas con mayor edad\n\n");
    
    for(i=0;i<10;i++)
    {
         if(edad[i]==mayor)
         {
            printf("\t%s\n",nombre[i]);                
         }           
    }
    
    /////////////////////////////////////////////////
    
    system("PAUSE");
}
